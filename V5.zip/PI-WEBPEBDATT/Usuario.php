<?php

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos-e-imagens/Usuario-style.css">
    <title>Perfil</title>
</head>
<body>
    <header>
        <nav class="navbar">
            <button class="black selected">EDITAR PERFIL</button>
            <button class="green">HOME</button>
            <button class="black">NOTIFICAÇÕES</button>
            <button class="green">SEGUINDO</button>
            <button class="black">PERGUNTAS</button>
        </nav>
    </header>
    <main>
        <section class="profile">
            <!-- Foto de perfil com a opção de alterar -->
            <div class="profile-pic">
                <img id="profileImage" src="estilos-e-imagens/imagens/Modelo-Perfil.png" alt="Foto do usuário">
                <span class="camera-icon">&#128247;</span>
                <!-- Input file escondido para upload de imagem -->
                <input type="file" id="fileInput" accept="image/*" style="display:none;" onchange="changeProfileImage(event)">
            </div>
            <h2 id="username" contenteditable="true" onblur="saveUsername()">Username</h2>
            <p id="userDescription" contenteditable="true" onblur="saveDescription()">Escreva uma descrição sobre você mesmo</p>
        </section>
        <section class="profile-info">
            <div class="info-item">
                <span class="icon">&#x1F393;</span> ESTUDANTE ...
            </div>
            <div class="info-item">
                <span class="icon">&#x1F4CD;</span> LOCAL ...
            </div>
            <div class="info-item">
                <span class="icon">&#x1F4C5;</span> QUANDO ENTROU ...
            </div>
        </section>
    </main>

    <script>
        // Função para salvar o nome de usuário após edição
        function saveUsername() {
            const username = document.getElementById("username").textContent;
            console.log("Novo nome de usuário:", username);
        }

        // Função para salvar a descrição após edição
        function saveDescription() {
            const description = document.getElementById("userDescription").textContent;
            console.log("Nova descrição:", description);
        }

        // Função para abrir o input file ao clicar na foto de perfil
        document.getElementById('profileImage').addEventListener('click', function() {
            document.getElementById('fileInput').click();
        });

        // Função para alterar a foto de perfil
        function changeProfileImage(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profileImage').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>