<?php
$user = 'root';
$senha = '';
$db = 'pinovo';
$host = 'localhost';

$banco = new mysqli($host, $user, $senha, $db);
?>