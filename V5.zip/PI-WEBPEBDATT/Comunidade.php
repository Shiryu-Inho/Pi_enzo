<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Comunidade</title>
</head>
<body>
    <h1>Bem-vindo à Comunidade</h1>
    <form method="POST">
        <textarea name="content" placeholder="Escreva algo..." required></textarea>
        <br>
        <button type="submit">Publicar</button>
    </form>
    <h2>Publicações</h2>
    <?php foreach ($posts as $post): ?>
        <div>
            <strong><?php echo htmlspecialchars($post['username']); ?></strong>
            <p><?php echo htmlspecialchars($post['content']); ?></p>
            <small><?php echo $post['created_at']; ?></small>
        </div>
        <hr>
    <?php endforeach; ?>
    <a href="logout.php">Sair</a>
</body>
</html>